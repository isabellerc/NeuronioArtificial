﻿// See https://aka.ms/new-console-template for more information
using ConsoleApp1;

Console.WriteLine("Hello, World!");

NeuronioArtificial neuronioArtificial = new NeuronioArtificial(0.5);

//criam a lista de entrada e treinar ele com metodo abaixo
//neuronioArtificial.Treinar();

//De perguntar pra ele


//O que precisa ser feito

//Gerar os pesos aleatorios
//Funcao de calcular o erro
//Funcao de calcular os novos pesos
//Funcao de obter resposta no metodo Perguntar
//Ajustar program.cs o treinamento e testar