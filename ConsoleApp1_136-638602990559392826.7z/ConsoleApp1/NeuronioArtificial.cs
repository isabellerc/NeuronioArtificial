﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class NeuronioArtificial
    {       
        public Pesos pesos { get; private set; }

        public double o { get; private set; }

        public double taxaAprendizado { get; private set; }

        public NeuronioArtificial(double pTaxaAprendizado)
        {
            o = 0.0;
            taxaAprendizado = pTaxaAprendizado;
            pesos = new Pesos();
            this.taxaAprendizado = taxaAprendizado;

        }

        public void Treinar(List<Entradas> listaEntradas)
        {

            foreach (var item in listaEntradas)
            {
                o = item.Entrada1 * pesos.W1 
                    + item.Entrada2 * pesos.W2;
               if(FuncaoClassificacao(o) != item.ResultadoEsperado)
                {
                    //recalcular os pesos
                }

            }
        }

        private int FuncaoClassificacao(double o)
        {
            if (o >= 0) return 1; return 0;
        }

      
        private bool CalcularErro()
        {
            return true;
        }
        private double RecalcularNovoPeso()
        {
            return 0.0;
            //codificar aqui
        }

        public int Perguntar(double X1, double X2)
        {
            return 1;
            //vai ter responder 0 ou 1;
        }
    }
}
